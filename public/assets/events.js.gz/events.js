(function() {

  jQuery(function() {});

}).call(this);
